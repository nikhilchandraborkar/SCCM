Available variables:

%USERNAME%
%COMPUTERNAME%
%DAYSLEFT%